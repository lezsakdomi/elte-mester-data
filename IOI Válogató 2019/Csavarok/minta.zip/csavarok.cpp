#include "csavarok.h"
#include <bits/stdc++.h>
#define maxN 100001

using namespace std;

int n;
int db;
int apa[maxN];
int anya[maxN];
bool Init=true;

int kezdet(){
    cin >> n;
    db=0;
    for (int i=0;i<n;i++) {
        cin >> apa[i];
    }
    for (int i=0;i<n;i++) {
        cin >> anya[i];
    }
    Init=false;
    return n;
}
void Hiba(string uzi){
  cout<<uzi<<endl;
  cout<<"0\n"; cout<<"-1\n";
  exit(0);
}
int proba(int a, int b){
  if(Init){
    Hiba("Protokoll hiba, előbb kezdet kell!");
  }
    db++;
    if ((a<1) || (a>n) || (b<1) || (b>n)) {
      Hiba("Hiba, hibás sorszám!");
    }
    if (apa[a-1]<anya[b-1]) {
        return -1;
    } else if (apa[a-1]==anya[b-1]) {
        return 0;
    } else {
        return 1;
    }
}

void eredmeny(int b[]){
  if(Init) Hiba("Protokoll hiba, előbb kezdet kell!");

    bool jo=true;
    for (int i=0;i<n;i++) {
        if ((b[i]>=1) && (b[i]<=n) && (apa[i]==anya[b[i]-1])) {
        } else {
            jo=false;
        }
    }
    long korlat=n; korlat=korlat*korlat/4;
    cout << (jo?"TRUE":"FALSE") << endl;
    cout << db <<" "<< korlat << endl;
    exit(0);
}
