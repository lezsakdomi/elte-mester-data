#include "ellenfel.h"
#include <iostream>
#include <string>
#include <vector>

bool init = true;
long n, u;

void Kiir(int, std::string msg) {
	std::cout << msg << std::endl;
}

long GetN() {
	init = false;
	std::cin >> n;
	u = (n - 1) / 2;
	return n;
}

long Elvesz(long x) {
	if (init) {
		Kiir(0, "hiba, először GetN-t kell hívni");
	}
	if (x > 2 * u || x > n) {
		Kiir(0, "hiba, érvénytelen lépés");
	}
	n -= x;
	u = x;
	if (n == 0) {
		Kiir(1, "helyes");
	}
	long l2 = n <= 2 * u ? n : 1;
	n -= l2;
	if (n = 0) {
		Kiir(0, "hiba, vesztettél");
	}
	u = l2;
	return l2;
}
