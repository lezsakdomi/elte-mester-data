#ifdef __cplusplus
extern "C" {
#endif

extern int Meret (void);
extern int Tabla (int i);
extern void EnLep (int L);
extern int TeLep (void);

#ifdef __cplusplus
}
#endif
