#include <bits/stdc++.h>
#define maxN 800001

using namespace std;
struct FaPont{
    int hany;
    int Fiuk[26];
    int elotte;
};
FaPont Fa[maxN];
int n,p;
int szabad=1;

void Faba(char s[32]){
    int p=0, fiu, eloz=0, f;
    for(int i=0;s[i]!=0 ;i++){
        f=s[i]-'a';
        Fa[p].hany++;
        eloz+=Fa[p].hany;
        fiu=Fa[p].Fiuk[f];
        if(fiu==0){
            fiu=szabad++;
            Fa[fiu].hany=0;
            Fa[fiu].elotte=0;
            Fa[p].Fiuk[f]=fiu;
            p=fiu;
        }else{
            p=fiu;
        }
    }
    Fa[p].hany++;
    eloz+=Fa[p].hany;
    Fa[p].elotte=eloz;
}
int Keres(char s[32]){
    int p=0, mego=n, fiu, f,i=0;
    while(s[i]!=0){
        fiu=Fa[p].Fiuk[s[i]-'a'];
        if(fiu==0){
            break;
        }else{
            p=fiu;
            mego+=Fa[p].hany;
        }
        i++;
    }
    if(s[i]==0 && Fa[p].elotte>0)
        return Fa[p].elotte;
    else
        return mego;
}
int main() {
    int k,m;
    scanf( "%d", &n );
    char s[32];
    for(int i=0;i<26;i++) Fa[0].Fiuk[i]=0;
    Fa[0].hany=0; Fa[0].elotte=0;
    for(int i=1;i<=n;i++){
        scanf( "%s", s);
        Faba(s);
    }
    scanf( "%d", &k);
    for(int i=1;i<=k;i++){
        scanf( "%s", s);
        m=Keres(s);
        printf( "%d\n", m );
    }
}
